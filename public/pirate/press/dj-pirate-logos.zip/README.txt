Placeholder - Pack logo de DJ Pirate a completer (voir TODO dans le rapport).
Remplacer ce fichier par les vrais fichiers logo (SVG/PNG, versions claires et sombres) avant mise en production.
