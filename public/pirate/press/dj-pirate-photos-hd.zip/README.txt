Placeholder - Pack photos HD de DJ Pirate a completer (voir TODO dans le rapport).
Remplacer ce fichier par un vrai pack de photos haute definition avant mise en production.
